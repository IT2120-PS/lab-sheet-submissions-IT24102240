setwd("D:\\Sliit\\01.Uni\\Y2S1\\4.PS\\labs\\Lab 09")

#1) sample of 25
data <- rnorm(25, mean = 45, sd = 2)
data

#2 One-sample t-test
result <- t.test(data, mu = 46, alternative = "less")
result