setwd("D:\\Sliit\\01.Uni\\Y2S1\\4.PS\\labs\\Lab 05")

#1.Import dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
View(Delivery_Times)

#2.
#Breaks from 20 to 70 with 9 intervals
breaks <- seq(20, 70, length.out = 10)

#Histogram
hist(Delivery_Times$Delivery_Time_.minutes.,
     breaks = breaks,
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     col = "lightblue",
     border = "black")

#3 Comment
#The distribution of delivery times is approximately symmetric but slightly right-skewed, 
#indicating most deliveries take around 30–55 minutes

#4.Frequency Polygon
#Create frequency table
freq_table <- hist(Delivery_Times$Delivery_Time_.minutes.,
                   breaks = breaks,
                   right = FALSE,
                   plot = FALSE)

#Cumulative frequencies
cum_freq <- cumsum(freq_table$counts)

#Midpoints for ogive
mids <- freq_table$breaks[-1]

#Plot ogive
plot(mids, cum_freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "blue", lwd = 2)
