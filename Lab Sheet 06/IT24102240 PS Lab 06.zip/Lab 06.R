setwd("D:/Sliit/01.Uni/Y2S1/4.PS/labs/Lab 06")

#Q1: Binomial
n <- 50
p <- 0.85

print(paste("X ~ Binomial(n =", n, ", p =", p, ")"))

#Probability at least 47
prob_at_least_47 <- 1 - pbinom(46, size = n, prob = p)  # P(X >= 47)
print(paste("P(X >= 47) =", prob_at_least_47))


#Problem 2: Poisson
lambda <- 12
print(paste("X ~ Poisson(lambda =", lambda, ")"))

# Exactly 15 calls
prob_eq_15 <- dpois(15, lambda = lambda)
print(paste("P(X = 15) =", prob_eq_15))

# Print expected values for sanity
print(paste("Expected value E[X] for Binomial (Problem1) =", n * p))
print(paste("Expected value E[X] for Poisson (Problem2) =", lambda))