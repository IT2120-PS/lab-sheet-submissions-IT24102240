setwd("D:/Sliit/01.Uni/Y2S1/4.PS/labs/Lab 07")

#Q1-Train uniform between 0 and 40 minutes
punif(25, 0, 40) - punif(10, 0, 40)

#Q2-Exponential with rate lambda
rate2 <- 1/3
pexp(2, rate=rate2)

#Q3-IQ
#i.P(IQ > 130)
pnorm(130, mean=100, sd=15, lower.tail=FALSE)
#ii.IQ score for 95th percentile
qnorm(0.95, mean=100, sd=15)
