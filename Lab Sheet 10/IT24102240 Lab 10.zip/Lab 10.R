setwd("D:\\Sliit\\01.Uni\\Y2S1\\4.PS\\labs\\Lab 10\\IT24102240 Lab 10")

observed_counts <- c(120,95,85,100)
chisq.test(x = observed_counts)